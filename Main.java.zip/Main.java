
public class EmployeeApp {

    public static void main(String[] args) {

        System.out.println("================================");
        System.out.println("   Employee Management System");
        System.out.println("================================");

        int employeeId = 101;
        String employeeName = "Rahul";
        String department = "DevOps";
        double salary = 35000.00;

        System.out.println("Employee ID   : " + employeeId);
        System.out.println("Employee Name : " + employeeName);
        System.out.println("Department    : " + department);
        System.out.println("Salary        : " + salary);

        System.out.println("--------------------------------");
        System.out.println("Application is running successfully!");
    }
}
